import Foundation
import UIKit
import UserNotifications

enum EventReminders {
    enum Failure: LocalizedError {
        case permissionDenied, tooLate

        var errorDescription: String? {
            switch self {
            case .permissionDenied:
                "Erlaube Mitteilungen für Movie Bar in den iPhone-Einstellungen."
            case .tooLate:
                "Die Erinnerungszeit ist bereits vorbei."
            }
        }
    }

    static func pendingIDs() async -> Set<String> {
        let requests = await UNUserNotificationCenter.current().pendingNotificationRequests()
        return Set(requests.map(\.identifier))
    }

    static func schedule(for event: MovieProgram.Event) async throws {
        let center = UNUserNotificationCenter.current()
        guard event.reminderDate(relativeTo: Date()) != nil else { throw Failure.tooLate }
        guard try await center.requestAuthorization(options: [.alert, .sound]) else {
            throw Failure.permissionDenied
        }
        guard let reminderDate = event.reminderDate(relativeTo: Date()) else {
            throw Failure.tooLate
        }

        let content = UNMutableNotificationContent()
        content.title = "In einer Stunde im Movie"
        content.body = "\(event.title) · \(event.timeLabel)"
        content.sound = .default
        let components = MovieProgram.calendar.dateComponents(
            [.calendar, .timeZone, .year, .month, .day, .hour, .minute],
            from: reminderDate
        )
        let trigger = UNCalendarNotificationTrigger(dateMatching: components, repeats: false)
        try await center.add(UNNotificationRequest(identifier: event.reminderID, content: content, trigger: trigger))
    }

    static func cancel(for event: MovieProgram.Event) {
        UNUserNotificationCenter.current().removePendingNotificationRequests(withIdentifiers: [event.reminderID])
    }
}

final class MovieAppDelegate: NSObject, UIApplicationDelegate, UNUserNotificationCenterDelegate {
    func application(
        _ application: UIApplication,
        didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]? = nil
    ) -> Bool {
        UNUserNotificationCenter.current().delegate = self
        return true
    }

    func userNotificationCenter(
        _ center: UNUserNotificationCenter,
        willPresent notification: UNNotification
    ) async -> UNNotificationPresentationOptions {
        [.banner, .list, .sound]
    }
}

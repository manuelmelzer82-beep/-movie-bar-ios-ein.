import Foundation

enum MovieProgram {
    struct Day: Identifiable {
        let id: Int
        let name: String
        var opens: Int? = nil
        var closes: Int? = nil
        var action: String? = nil
        var programDetail: String? = nil

        var hours: String {
            guard let opens, let closes else { return "Geschlossen" }
            return "\(MovieProgram.hour(opens))–\(MovieProgram.hour(closes)) Uhr"
        }

        func isOpen(at hour: Int) -> Bool {
            guard let opens, let closes else { return false }
            return hour >= opens && (closes < opens || hour < closes)
        }

        func isOpenAfterMidnight(at hour: Int) -> Bool {
            guard let opens, let closes else { return false }
            return closes < opens && hour < closes
        }
    }

    struct Event: Identifiable {
        let id: String
        let date: Date
        let hour: Int?
        let title: String
        let detail: String
        let acceptsRegistration: Bool

        var dateLabel: String {
            date.formatted(MovieProgram.eventDateStyle)
        }

        var timeLabel: String {
            hour.map { "\(MovieProgram.hour($0)) Uhr" } ?? "Uhrzeit folgt"
        }

        var reminderID: String { "movie.event.\(id)" }

        func reminderDate(relativeTo now: Date) -> Date? {
            guard hour != nil else { return nil }
            let reminder = date.addingTimeInterval(-3_600)
            return reminder > now ? reminder : nil
        }

        var registrationURL: URL? {
            guard acceptsRegistration else { return nil }
            var components = URLComponents()
            components.scheme = "https"
            components.host = "wa.me"
            components.path = "/4917684679289"
            components.queryItems = [
                URLQueryItem(
                    name: "text",
                    value: "Hallo Manuel, ich möchte mich für die Dart-Qualifikation am \(dateLabel) anmelden."
                )
            ]
            return components.url
        }
    }

    struct Jackpot: Identifiable {
        let id: String
        let name: String
        let symbol: String
        var amount: Decimal? = nil
    }

    static let timeZone = TimeZone(identifier: "Europe/Berlin")!
    static let german = Locale(identifier: "de_DE")
    static let calendar: Calendar = {
        var calendar = Calendar(identifier: .gregorian)
        calendar.timeZone = timeZone
        return calendar
    }()

    static let week = [
        Day(id: 2, name: "Montag"),
        Day(id: 3, name: "Dienstag", opens: 18, closes: 22, action: "Rubbellose",
            programDetail: "Ein Rubbellos pro Gast und Tag"),
        Day(id: 4, name: "Mittwoch", opens: 18, closes: 22, action: "Movie Bingo"),
        Day(id: 5, name: "Donnerstag", opens: 18, closes: 22, action: "Bierbonuskarte · 10 + 1"),
        Day(id: 6, name: "Freitag", opens: 18, closes: 3, action: "Tombola & Jukebox",
            programDetail: "Ein Los pro Gast und Tag · Wunschmusik"),
        Day(id: 7, name: "Samstag", opens: 18, closes: 3, action: "Tombola & Mottoabend",
            programDetail: "Ein Los pro Gast und Tag · Mottoabend ab 20:00 Uhr"),
        Day(id: 1, name: "Sonntag", opens: 10, closes: 15, action: "Bierbonuskarte · 10 + 1",
            programDetail: "Frühschoppen von 10:00 bis 15:00 Uhr")
    ]

    static let weeklyProgramPeriod = "Oktober 2026 – Mai 2027"
    static let challengeSchedule = "10-Sekunden-Challenge · Dienstag bis Sonntag"
    static let challengeRules = "Ein kostenloser Versuch pro Tag, weitere Versuche je 1 €. Der Jackpot wächst jede Woche um 25 €."

    static let events = [
        party(year: 2026, month: 11, day: 7, title: "70er Hits"),
        party(year: 2026, month: 11, day: 14, title: "Country Night"),
        party(year: 2026, month: 11, day: 21, title: "Party Hits", detail: "Mallorca, Charts, Deutschpop und Rock"),
        qualification(year: 2026, month: 11, day: 28),
        party(year: 2026, month: 11, day: 28, title: "Black & White Party", detail: "Dresscode Schwarz oder Weiß"),
        party(year: 2026, month: 12, day: 5, title: "Après-Ski-Party"),
        qualification(year: 2026, month: 12, day: 12),
        party(year: 2026, month: 12, day: 12, title: "X-Mas-Party"),
        qualification(year: 2026, month: 12, day: 19),
        party(year: 2026, month: 12, day: 19, title: "Weihnachts-Special"),
        party(year: 2026, month: 12, day: 24, title: "Weihnachtsparty"),
        party(year: 2026, month: 12, day: 31, title: "Silvesterparty"),
        Event(
            id: "2027-01-02",
            date: localDate(year: 2027, month: 1, day: 2),
            hour: nil,
            title: "1. Movie Dart-WM · Finale",
            detail: "Finale für qualifizierte Spielerinnen und Spieler",
            acceptsRegistration: false
        ),
        party(year: 2027, month: 1, day: 9, title: "80er/90er-Party"),
        party(year: 2027, month: 1, day: 16, title: "Rock Night"),
        party(year: 2027, month: 1, day: 23, title: "Mallorca Party"),
        party(year: 2027, month: 1, day: 30, title: "Country Night")
    ]

    static let jackpots = [
        Jackpot(id: "bingo", name: "Movie Bingo", symbol: "circle.grid.3x3.fill"),
        Jackpot(id: "challenge", name: "10-Sekunden-Challenge", symbol: "stopwatch")
    ]

    static func openingStatus(at now: Date) -> (today: Day, isOpen: Bool, overnightClosing: Int?) {
        let weekday = calendar.component(.weekday, from: now)
        let todayIndex = (weekday + 5) % week.count
        let today = week[todayIndex]
        let previous = week[(todayIndex + week.count - 1) % week.count]
        let currentHour = calendar.component(.hour, from: now)
        let overnightClosing = previous.isOpenAfterMidnight(at: currentHour) ? previous.closes : nil
        return (today, overnightClosing != nil || today.isOpen(at: currentHour), overnightClosing)
    }

    static func isWeeklyProgramActive(at now: Date) -> Bool {
        now >= localDate(year: 2026, month: 10, day: 1)
            && now < localDate(year: 2027, month: 6, day: 1)
    }

    static func isUpcoming(_ event: Event, at now: Date) -> Bool {
        if event.hour != nil {
            return event.date > now
        }
        return calendar.startOfDay(for: event.date) >= calendar.startOfDay(for: now)
    }

    static func hour(_ value: Int) -> String {
        String(format: "%02d:00", value)
    }

    private static let eventDateStyle = Date.FormatStyle(
        date: .numeric, locale: german, calendar: calendar, timeZone: timeZone
    )

    private static func localDate(year: Int, month: Int, day: Int, hour: Int = 0) -> Date {
        calendar.date(from: DateComponents(year: year, month: month, day: day, hour: hour))!
    }

    private static func qualification(year: Int, month: Int, day: Int) -> Event {
        Event(
            id: String(format: "%04d-%02d-%02d", year, month, day),
            date: localDate(year: year, month: month, day: day, hour: 12),
            hour: 12,
            title: "Movie Dart · Qualifikation",
            detail: "501 Straight Out · 10 € Startgeld + 5 € Boardgebühr",
            acceptsRegistration: true
        )
    }

    private static func party(year: Int, month: Int, day: Int, title: String, detail: String = "") -> Event {
        Event(
            id: String(format: "%04d-%02d-%02d-party", year, month, day),
            date: localDate(year: year, month: month, day: day, hour: 20),
            hour: 20,
            title: title,
            detail: detail,
            acceptsRegistration: false
        )
    }
}

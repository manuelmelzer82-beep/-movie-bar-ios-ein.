import SwiftUI

@main
struct MovieBarApp: App {
    @UIApplicationDelegateAdaptor(MovieAppDelegate.self) private var appDelegate
    @State private var tab = MovieTab.today

    var body: some Scene {
        WindowGroup {
            VStack(spacing: 0) {
                MovieMenu(selection: $tab)

                TabView(selection: $tab) {
                    TodayView { tab = .calendar }
                        .tag(MovieTab.today)
                        .tabItem { Label("Startseite", systemImage: "house") }

                    EventsView()
                        .tag(MovieTab.calendar)
                        .tabItem { Label("Kalender", systemImage: "calendar") }

                    JackpotsView()
                        .tag(MovieTab.jackpots)
                        .tabItem { Label("Jackpots", systemImage: "trophy") }
                }
            }
            .background(MovieStyle.background.ignoresSafeArea())
            .tint(MovieStyle.green)
            .preferredColorScheme(.dark)
            .environment(\.locale, MovieProgram.german)
        }
    }
}

private enum MovieTab: Hashable {
    case today, calendar, jackpots
}

private let movieWebsite = URL(string: "https://www.movie-bar-meckenbeuren.de/")!

private struct MovieMenu: View {
    private struct Entry: Identifiable {
        let title: String
        let id: String
        var tab: MovieTab? = nil
    }

    private let entries = [
        Entry(title: "Startseite", id: "heute", tab: .today),
        Entry(title: "Steckbrief", id: "steckbrief"),
        Entry(title: "Wochenprogramm", id: "wochenprogramm"),
        Entry(title: "Kalender", id: "events", tab: .calendar),
        Entry(title: "Dart", id: "dart"),
        Entry(title: "Reservieren", id: "reservieren"),
        Entry(title: "Getränkekarte", id: "getraenkekarte"),
        Entry(title: "Jackpots", id: "jackpots", tab: .jackpots),
        Entry(title: "Gästebuch", id: "gaestebuch"),
        Entry(title: "Anfahrt", id: "anfahrt"),
        Entry(title: "Kontakt", id: "kontakt"),
        Entry(title: "Impressum", id: "impressum")
    ]

    @Binding var selection: MovieTab
    @State private var leadingEntry: String?
    @Environment(\.accessibilityReduceMotion) private var reduceMotion

    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            Button { selection = .today } label: { MovieBrand() }
                .accessibilityHint("Öffnet die Startseite")

            HStack(spacing: 4) {
                scrollButton(-1, symbol: "chevron.left", label: "Menü nach links scrollen")
                ScrollView(.horizontal) {
                    HStack(spacing: 4) {
                        ForEach(entries) { entry in
                            if let tab = entry.tab {
                                Button { selection = tab } label: {
                                    menuLabel(entry.title, selected: selection == tab)
                                }
                                .accessibilityAddTraits(selection == tab ? .isSelected : [])
                            } else {
                                Link(destination: movieWebsite.appending(fragment: entry.id)) {
                                    menuLabel(entry.title)
                                }
                            }
                        }
                    }
                    .scrollTargetLayout()
                }
                .scrollPosition(id: $leadingEntry, anchor: .leading)
                .accessibilityLabel("Hauptnavigation")
                scrollButton(1, symbol: "chevron.right", label: "Menü nach rechts scrollen")
            }
        }
        .buttonStyle(.plain)
        .padding(.horizontal, 14)
        .padding(.vertical, 7)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(MovieStyle.chrome)
        .overlay(alignment: .bottom) { Divider().overlay(MovieStyle.outline) }
        .onChange(of: selection) { _, tab in
            guard let entry = entries.first(where: { $0.tab == tab }) else { return }
            scroll(to: entry.id)
        }
    }

    private func menuLabel(_ title: String, selected: Bool = false) -> some View {
        Text(title)
            .font(.subheadline.weight(.semibold))
            .fixedSize(horizontal: true, vertical: false)
            .padding(.horizontal, 7)
            .frame(minHeight: 44)
            .foregroundStyle(selected ? MovieStyle.green : Color.primary)
            .background(selected ? MovieStyle.panel : Color.clear, in: RoundedRectangle(cornerRadius: 6))
            .contentShape(Rectangle())
    }

    private func scrollButton(_ direction: Int, symbol: String, label: String) -> some View {
        Button {
            let index = entries.firstIndex(where: { $0.id == leadingEntry }) ?? 0
            let nextIndex = min(max(index + direction * 2, 0), entries.count - 1)
            scroll(to: entries[nextIndex].id)
        } label: {
            Image(systemName: symbol)
                .font(.footnote.weight(.semibold))
                .frame(width: 32, height: 32)
                .background(MovieStyle.panel, in: RoundedRectangle(cornerRadius: 6))
                .frame(width: 44, height: 44)
                .contentShape(Rectangle())
        }
        .accessibilityLabel(label)
    }

    private func scroll(to id: String) {
        withAnimation(reduceMotion ? nil : .easeInOut(duration: 0.2)) {
            leadingEntry = id
        }
    }
}

private enum MovieStyle {
    static let background = Color(red: 0.035, green: 0.078, blue: 0.047)
    static let panel = Color(red: 0.095, green: 0.15, blue: 0.11)
    static let chrome = background
    static let status = Color(red: 17 / 255.0, green: 30 / 255.0, blue: 21 / 255.0)
    static let accent = Color(red: 166 / 255.0, green: 237 / 255.0, blue: 176 / 255.0)
    static let dateBackground = Color(red: 35 / 255.0, green: 60 / 255.0, blue: 43 / 255.0)
    static let outline = Color(red: 0.31, green: 0.39, blue: 0.34)
    static let silver = Color(red: 0.79, green: 0.82, blue: 0.80)
    static let green = Color(red: 0.58, green: 0.88, blue: 0.61)
    static let red = Color(red: 1, green: 0.51, blue: 0.49)
}

private struct MoviePage<Content: View>: View {
    let title: String
    @ViewBuilder let content: Content

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 12) {
                    content
                }
                .frame(maxWidth: 620)
                .padding(14)
                .frame(maxWidth: .infinity)
            }
            .background(MovieStyle.background.ignoresSafeArea())
            .navigationTitle(title)
            .navigationBarTitleDisplayMode(.large)
            .toolbar(title.isEmpty ? .hidden : .visible, for: .navigationBar)
            .toolbarBackground(MovieStyle.chrome, for: .navigationBar, .tabBar)
            .toolbarBackground(.visible, for: .navigationBar, .tabBar)
        }
    }
}

private struct MovieBrand: View {
    var body: some View {
        HStack(spacing: 8) {
            Image("MovieWebMark")
                .resizable()
                .scaledToFit()
                .frame(width: 32, height: 32)
                .clipShape(RoundedRectangle(cornerRadius: 6))
                .accessibilityHidden(true)
            VStack(alignment: .leading, spacing: 2) {
                Text("Movie Bar").font(.subheadline.bold())
                Text("MECKENBEUREN")
                    .font(.caption2.bold())
                    .tracking(0.9)
                    .foregroundStyle(MovieStyle.silver)
            }
        }
        .accessibilityElement(children: .combine)
    }
}

private extension View {
    func moviePanel(_ fill: Color = MovieStyle.panel) -> some View {
        let shape = RoundedRectangle(cornerRadius: 16)
        return clipShape(shape)
            .background(fill, in: shape)
            .overlay {
                shape.strokeBorder(MovieStyle.outline)
                    .allowsHitTesting(false)
            }
    }

    func movieCard(fill: Color = MovieStyle.panel) -> some View {
        padding(16)
            .frame(maxWidth: .infinity, alignment: .leading)
            .moviePanel(fill)
    }
}

private struct TodayView: View {
    let showCalendar: () -> Void

    var body: some View {
        MoviePage(title: "") {
            introduction

            TimelineView(.periodic(from: .now, by: 30)) { context in
                let status = MovieProgram.openingStatus(at: context.date)

                VStack(alignment: .leading, spacing: 10) {
                    Text("Öffnungszeiten")
                        .font(.title2.bold())
                        .accessibilityAddTraits(.isHeader)
                    Text("HEUTE IM MOVIE")
                        .font(.caption.bold())
                        .tracking(1.2)
                        .foregroundStyle(MovieStyle.green)
                    Label(
                        status.isOpen ? "Laut Plan geöffnet" : "Laut Plan geschlossen",
                        systemImage: status.isOpen ? "door.left.hand.open" : "door.left.hand.closed"
                    )
                    .font(.caption.weight(.semibold))
                    .foregroundStyle(status.isOpen ? MovieStyle.green : MovieStyle.red)
                    .padding(.horizontal, 10)
                    .padding(.vertical, 5)
                    .overlay { Capsule().strokeBorder(MovieStyle.outline) }

                    Text(status.today.name)
                        .font(.title2.bold())
                        .accessibilityAddTraits(.isHeader)
                    Text(status.today.hours)
                        .font(.headline)
                    if let closing = status.overnightClosing {
                        Text("Noch geöffnet bis \(MovieProgram.hour(closing)) Uhr")
                            .foregroundStyle(MovieStyle.green)
                    } else if MovieProgram.isWeeklyProgramActive(at: context.date), let action = status.today.action {
                        Text(action).foregroundStyle(MovieStyle.silver)
                    }

                    Divider().overlay(MovieStyle.outline)
                    ForEach(MovieProgram.week) { day in
                        LabeledContent(day.name, value: day.hours)
                            .font(.subheadline)
                    }
                    Text("Schließzeiten flexibel.")
                        .font(.footnote)
                        .foregroundStyle(MovieStyle.silver)
                }
                .movieCard(fill: MovieStyle.status)
            }

            VStack(alignment: .leading, spacing: 12) {
                Text("Heute an der Bar")
                    .font(.title3.bold())
                    .accessibilityAddTraits(.isHeader)
                Link(destination: movieWebsite.appending(fragment: "getraenkekarte")) {
                    Label("Zur Getränkekarte", systemImage: "list.bullet")
                }
                Link(destination: movieWebsite.appending(fragment: "heute")) {
                    Label("Tagesangebot auf der Homepage ansehen", systemImage: "arrow.up.right")
                }
                .font(.footnote)
            }
            .movieCard()
        }
    }

    private var introduction: some View {
        VStack(alignment: .leading, spacing: 0) {
            VStack(alignment: .leading, spacing: 12) {
                Text("BROCHENZELLER STRASSE 26")
                    .font(.caption.bold())
                    .tracking(1.2)
                    .foregroundStyle(MovieStyle.green)

                Text("Movie Bar\nMeckenbeuren")
                    .font(.largeTitle.bold())
                    .accessibilityAddTraits(.isHeader)

                Text("Dart, Movie Bingo und Musikabende")
                    .foregroundStyle(MovieStyle.silver)

                Link("Tisch reservieren", destination: movieWebsite.appending(fragment: "reservieren"))
                    .font(.subheadline.bold())
                    .buttonStyle(.borderedProminent)
                    .tint(MovieStyle.accent)
                    .foregroundStyle(MovieStyle.background)

                ViewThatFits(in: .horizontal) {
                    HStack(spacing: 18) { introductionLinks }
                    VStack(alignment: .leading, spacing: 12) { introductionLinks }
                }
                .font(.subheadline.weight(.semibold))
            }
            .padding(20)
            .frame(maxWidth: .infinity, alignment: .leading)

            Link(destination: movieWebsite.appending(fragment: "anfahrt")) {
                Image("MovieExterior")
                    .resizable()
                    .scaledToFit()
                    .frame(maxWidth: .infinity)
                    .accessibilityHidden(true)
            }
            .accessibilityLabel("Eingang und Terrasse der Movie Bar, Anfahrt öffnen")
        }
        .moviePanel()
    }

    @ViewBuilder
    private var introductionLinks: some View {
        Button(action: showCalendar) {
            Text("Veranstaltungen").underline()
        }
        Link(destination: movieWebsite.appending(fragment: "anfahrt")) {
            Text("Anfahrt").underline()
        }
    }
}

private extension URL {
    func appending(fragment: String) -> URL {
        var components = URLComponents(url: self, resolvingAgainstBaseURL: false)
        components?.fragment = fragment
        return components?.url ?? self
    }
}

private struct EventsView: View {
    @Environment(\.scenePhase) private var scenePhase
    @State private var pendingIDs: Set<String> = []
    @State private var busyEvent: String?
    @State private var reminderError: String?
    @State private var showsError = false

    var body: some View {
        MoviePage(title: "Kalender") {
            TimelineView(.periodic(from: .now, by: 30)) { context in
                let upcoming = MovieProgram.events.filter { MovieProgram.isUpcoming($0, at: context.date) }
                let past = MovieProgram.events.filter { !MovieProgram.isUpcoming($0, at: context.date) }

                VStack(alignment: .leading, spacing: 12) {
                    weeklyProgram

                    if upcoming.isEmpty {
                        Text("Neue Termine folgen.").movieCard()
                    }

                    ForEach(upcoming) { event in
                        eventCard(event, now: context.date)
                    }

                    if !past.isEmpty {
                        DisclosureGroup("Vergangene Termine") {
                            VStack(alignment: .leading, spacing: 12) {
                                ForEach(past.reversed()) { event in
                                    eventCard(event, now: context.date, showsActions: false)
                                }
                            }
                            .padding(.top, 12)
                        }
                        .movieCard()
                    }
                }
            }
        }
        .task(id: scenePhase) {
            if scenePhase == .active {
                pendingIDs = await EventReminders.pendingIDs()
            }
        }
        .alert("Erinnerung", isPresented: $showsError) {
            Button("OK", role: .cancel) {}
        } message: {
            Text(reminderError ?? "Die Erinnerung konnte nicht eingerichtet werden.")
        }
    }

    private var weeklyProgram: some View {
        DisclosureGroup {
            VStack(alignment: .leading, spacing: 12) {
                ForEach(MovieProgram.week) { day in
                    VStack(alignment: .leading, spacing: 3) {
                        Text(day.name).font(.subheadline.weight(.semibold))
                        Text(day.action ?? "Geschlossen").foregroundStyle(MovieStyle.silver)
                        if let detail = day.programDetail {
                            Text(detail).font(.caption).foregroundStyle(MovieStyle.silver)
                        }
                    }
                }

                Text(MovieProgram.challengeSchedule).font(.subheadline.weight(.semibold))
                Text(MovieProgram.challengeRules).foregroundStyle(MovieStyle.silver)
            }
            .padding(.top, 12)
        } label: {
            VStack(alignment: .leading, spacing: 3) {
                Text("Wochenprogramm").font(.headline)
                Text(MovieProgram.weeklyProgramPeriod)
                    .font(.subheadline)
                    .foregroundStyle(MovieStyle.silver)
            }
        }
        .movieCard()
    }

    private func eventCard(_ event: MovieProgram.Event, now: Date, showsActions: Bool = true) -> some View {
        let hasReminder = pendingIDs.contains(event.reminderID)

        return VStack(alignment: .leading, spacing: 9) {
            Text("\(event.dateLabel) · \(event.timeLabel)")
                .font(.subheadline.weight(.semibold))
                .foregroundStyle(MovieStyle.green)
                .padding(.horizontal, 8)
                .padding(.vertical, 5)
                .background(MovieStyle.dateBackground, in: RoundedRectangle(cornerRadius: 7))
            Text(event.title)
                .font(.title3.bold())
                .accessibilityAddTraits(.isHeader)
            if !event.detail.isEmpty {
                Text(event.detail)
                    .foregroundStyle(MovieStyle.silver)
            }

            if showsActions, let url = event.registrationURL {
                Link(destination: url) {
                    Label("Per WhatsApp anmelden", systemImage: "message")
                }
                .buttonStyle(.bordered)
            }

            if showsActions, hasReminder || event.reminderDate(relativeTo: now) != nil {
                Button {
                    updateReminder(for: event, isScheduled: hasReminder)
                } label: {
                    Label(
                        hasReminder ? "Erinnerung ausschalten" : "1 Stunde vorher erinnern",
                        systemImage: hasReminder ? "bell.slash" : "bell"
                    )
                }
                .buttonStyle(.bordered)
                .disabled(busyEvent != nil)
            }
        }
        .movieCard()
    }

    private func updateReminder(for event: MovieProgram.Event, isScheduled: Bool) {
        busyEvent = event.id
        Task {
            defer { busyEvent = nil }

            if isScheduled {
                EventReminders.cancel(for: event)
                pendingIDs.remove(event.reminderID)
                return
            }

            do {
                try await EventReminders.schedule(for: event)
                pendingIDs.insert(event.reminderID)
            } catch {
                reminderError = (error as? EventReminders.Failure)?.errorDescription
                showsError = true
            }
        }
    }
}

private struct JackpotsView: View {
    var body: some View {
        MoviePage(title: "Jackpots") {
            ForEach(MovieProgram.jackpots) { jackpot in
                VStack(alignment: .leading, spacing: 8) {
                    Label(jackpot.name, systemImage: jackpot.symbol)
                        .font(.headline)
                        .foregroundStyle(MovieStyle.green)
                        .accessibilityAddTraits(.isHeader)

                    if let amount = jackpot.amount {
                        Text(amount.formatted(.currency(code: "EUR").locale(MovieProgram.german)))
                            .font(.title2.bold())
                    } else {
                        Text("Aktueller Stand folgt")
                            .foregroundStyle(MovieStyle.silver)
                    }
                }
                .movieCard()
            }
        }
    }
}

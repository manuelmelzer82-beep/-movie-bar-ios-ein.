import SwiftUI

@main
struct MovieBarApp: App {
    @UIApplicationDelegateAdaptor(MovieAppDelegate.self) private var appDelegate

    var body: some Scene {
        WindowGroup {
            TabView {
                TodayView()
                    .tabItem { Label("Heute", systemImage: "clock") }

                EventsView()
                    .tabItem { Label("Events", systemImage: "calendar") }

                JackpotsView()
                    .tabItem { Label("Jackpots", systemImage: "trophy") }
            }
            .tint(MovieStyle.green)
            .preferredColorScheme(.dark)
            .environment(\.locale, MovieProgram.german)
        }
    }
}

private enum MovieStyle {
    static let background = Color(red: 0.035, green: 0.078, blue: 0.047)
    static let panel = Color(red: 0.095, green: 0.15, blue: 0.11)
    static let chrome = Color(red: 0.065, green: 0.115, blue: 0.082)
    static let outline = Color(red: 0.31, green: 0.39, blue: 0.34)
    static let silver = Color(red: 0.79, green: 0.82, blue: 0.80)
    static let green = Color(red: 0.58, green: 0.88, blue: 0.61)
    static let red = Color(red: 1, green: 0.51, blue: 0.49)
}

private struct MoviePage<Content: View>: View {
    let title: String
    @ViewBuilder let content: Content

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 16) {
                    content
                }
                .frame(maxWidth: 620)
                .padding(20)
                .frame(maxWidth: .infinity)
            }
            .background(MovieStyle.background.ignoresSafeArea())
            .navigationTitle(title)
            .toolbarBackground(MovieStyle.chrome, for: .navigationBar, .tabBar)
            .toolbarBackground(.visible, for: .navigationBar, .tabBar)
        }
    }
}

private extension View {
    func movieCard() -> some View {
        self
            .padding(16)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(MovieStyle.panel, in: RoundedRectangle(cornerRadius: 20))
            .overlay {
                RoundedRectangle(cornerRadius: 20)
                    .strokeBorder(MovieStyle.outline, lineWidth: 1)
                    .allowsHitTesting(false)
            }
    }
}

private struct TodayView: View {
    var body: some View {
        MoviePage(title: "Heute im Movie") {
            VStack(alignment: .leading, spacing: 12) {
                Image("MovieLogo")
                    .resizable()
                    .scaledToFit()
                    .frame(maxWidth: 320)
                    .clipShape(RoundedRectangle(cornerRadius: 12))
                    .accessibilityHidden(true)

                Text("Movie Bar Meckenbeuren")
                    .font(.headline)
                    .foregroundStyle(MovieStyle.green)
                    .accessibilityAddTraits(.isHeader)
            }
            .frame(maxWidth: .infinity, alignment: .center)
            .movieCard()

            TimelineView(.periodic(from: .now, by: 30)) { context in
                let status = MovieProgram.openingStatus(at: context.date)

                VStack(alignment: .leading, spacing: 8) {
                    Label(
                        status.isOpen ? "Laut Plan geöffnet" : "Laut Plan geschlossen",
                        systemImage: status.isOpen ? "door.left.hand.open" : "door.left.hand.closed"
                    )
                    .font(.subheadline.weight(.semibold))
                    .foregroundStyle(status.isOpen ? MovieStyle.green : MovieStyle.red)

                    Text(status.today.name)
                        .font(.title2.bold())
                        .accessibilityAddTraits(.isHeader)
                    Text(status.today.hours)
                        .font(.headline)
                    if let closing = status.overnightClosing {
                        Text("Noch geöffnet bis \(MovieProgram.hour(closing)) Uhr")
                            .foregroundStyle(MovieStyle.green)
                    } else if MovieProgram.isWeeklyProgramActive(at: context.date), let action = status.today.action {
                        Text(action).foregroundStyle(MovieStyle.silver)
                    }
                }
                .movieCard()
            }

            VStack(alignment: .leading, spacing: 12) {
                Text("Reguläre Öffnungszeiten")
                    .font(.headline)
                    .accessibilityAddTraits(.isHeader)

                ForEach(MovieProgram.week) { day in
                    LabeledContent(day.name, value: day.hours)
                        .font(.subheadline)
                }
            }
            .movieCard()
        }
    }
}

private struct EventsView: View {
    @Environment(\.scenePhase) private var scenePhase
    @State private var pendingIDs: Set<String> = []
    @State private var busyEvent: String?
    @State private var reminderError: String?
    @State private var showsError = false

    var body: some View {
        MoviePage(title: "Events & Dart") {
            TimelineView(.periodic(from: .now, by: 30)) { context in
                let upcoming = MovieProgram.events.filter { MovieProgram.isUpcoming($0, at: context.date) }
                let past = MovieProgram.events.filter { !MovieProgram.isUpcoming($0, at: context.date) }

                VStack(alignment: .leading, spacing: 12) {
                    weeklyProgram

                    if upcoming.isEmpty {
                        Text("Neue Termine folgen.").movieCard()
                    }

                    ForEach(upcoming) { event in
                        eventCard(event, now: context.date)
                    }

                    if !past.isEmpty {
                        DisclosureGroup("Vergangene Termine") {
                            VStack(alignment: .leading, spacing: 12) {
                                ForEach(past.reversed()) { event in
                                    eventCard(event, now: context.date, showsActions: false)
                                }
                            }
                            .padding(.top, 12)
                        }
                        .movieCard()
                    }
                }
            }
        }
        .task(id: scenePhase) {
            if scenePhase == .active {
                pendingIDs = await EventReminders.pendingIDs()
            }
        }
        .alert("Erinnerung", isPresented: $showsError) {
            Button("OK", role: .cancel) {}
        } message: {
            Text(reminderError ?? "Die Erinnerung konnte nicht eingerichtet werden.")
        }
    }

    private var weeklyProgram: some View {
        DisclosureGroup {
            VStack(alignment: .leading, spacing: 12) {
                ForEach(MovieProgram.week) { day in
                    VStack(alignment: .leading, spacing: 3) {
                        Text(day.name).font(.subheadline.weight(.semibold))
                        Text(day.action ?? "Geschlossen").foregroundStyle(MovieStyle.silver)
                        if let detail = day.programDetail {
                            Text(detail).font(.caption).foregroundStyle(MovieStyle.silver)
                        }
                    }
                }

                Text(MovieProgram.challengeSchedule).font(.subheadline.weight(.semibold))
                Text(MovieProgram.challengeRules).foregroundStyle(MovieStyle.silver)
            }
            .padding(.top, 12)
        } label: {
            VStack(alignment: .leading, spacing: 3) {
                Text("Wochenprogramm").font(.headline)
                Text(MovieProgram.weeklyProgramPeriod)
                    .font(.subheadline)
                    .foregroundStyle(MovieStyle.silver)
            }
        }
        .movieCard()
    }

    private func eventCard(_ event: MovieProgram.Event, now: Date, showsActions: Bool = true) -> some View {
        let hasReminder = pendingIDs.contains(event.reminderID)

        return VStack(alignment: .leading, spacing: 9) {
            Text("\(event.dateLabel) · \(event.timeLabel)")
                .font(.subheadline.weight(.semibold))
                .foregroundStyle(MovieStyle.green)
            Text(event.title)
                .font(.title3.bold())
                .accessibilityAddTraits(.isHeader)
            if !event.detail.isEmpty {
                Text(event.detail)
                    .foregroundStyle(MovieStyle.silver)
            }

            if showsActions, let url = event.registrationURL {
                Link(destination: url) {
                    Label("Per WhatsApp anmelden", systemImage: "message")
                }
                .buttonStyle(.bordered)
            }

            if showsActions, hasReminder || event.reminderDate(relativeTo: now) != nil {
                Button {
                    updateReminder(for: event, isScheduled: hasReminder)
                } label: {
                    Label(
                        hasReminder ? "Erinnerung ausschalten" : "1 Stunde vorher erinnern",
                        systemImage: hasReminder ? "bell.slash" : "bell"
                    )
                }
                .buttonStyle(.bordered)
                .disabled(busyEvent != nil)
            }
        }
        .movieCard()
    }

    private func updateReminder(for event: MovieProgram.Event, isScheduled: Bool) {
        busyEvent = event.id
        Task {
            defer { busyEvent = nil }

            if isScheduled {
                EventReminders.cancel(for: event)
                pendingIDs.remove(event.reminderID)
                return
            }

            do {
                try await EventReminders.schedule(for: event)
                pendingIDs.insert(event.reminderID)
            } catch {
                reminderError = (error as? EventReminders.Failure)?.errorDescription
                showsError = true
            }
        }
    }
}

private struct JackpotsView: View {
    var body: some View {
        MoviePage(title: "Jackpots") {
            ForEach(MovieProgram.jackpots) { jackpot in
                VStack(alignment: .leading, spacing: 8) {
                    Label(jackpot.name, systemImage: jackpot.symbol)
                        .font(.headline)
                        .foregroundStyle(MovieStyle.green)
                        .accessibilityAddTraits(.isHeader)

                    if let amount = jackpot.amount {
                        Text(amount.formatted(.currency(code: "EUR").locale(MovieProgram.german)))
                            .font(.title2.bold())
                    } else {
                        Text("Aktueller Stand folgt")
                            .foregroundStyle(MovieStyle.silver)
                    }
                }
                .movieCard()
            }
        }
    }
}

# Movie Bar Meckenbeuren für iPhone

Erster Stand der iPhone-App, Version 1.0. Die App verwendet SwiftUI und ist für iOS 17 oder neuer eingerichtet.

## Auf einem Mac ausprobieren

1. ZIP entpacken und `MovieBar.xcodeproj` in Xcode öffnen.
2. Oben das Schema **MovieBar** und einen **iPhone-Simulator** auswählen. Mit **Run** (▶) starten. Für den Simulator ist kein Entwicklerteam erforderlich.
3. Für einen Test auf einem echten iPhone in Xcode unter **MovieBar → Signing & Capabilities → Team** das eigene Apple-Team auswählen. Wenn Xcode meldet, dass die Paketkennung belegt ist, eine eigene eindeutige Kennung eintragen.
4. Das verbundene iPhone als Ziel auswählen und die App mit **Run** starten. Auf dem Gerät die Turniererinnerung und den WhatsApp-Link ausprobieren.

## Inhalt der ersten Version

- **Heute** zeigt das Movie-Bar-Logo, die Öffnungszeiten und den Status nach regulärem Plan. Die Nachtstunden von Freitag und Samstag werden in der Zeitzone Europe/Berlin berücksichtigt.
- **Events** zeigt die Termine aus der Web-App. Bei Qualifikationsturnieren öffnet der WhatsApp-Link eine vorbereitete Nachricht. Gäste können eine lokale iPhone-Mitteilung für eine Stunde vor Turnierbeginn aktivieren oder wieder ausschalten.
- **Jackpots** führt Movie Bingo und die 10-Sekunden-Challenge auf. Die Beträge sind offen, bis aktuelle Stände vorliegen.

Öffnungszeiten, Veranstaltungen und Jackpotstände stehen in `MovieBar/MovieProgram.swift`. Änderungen brauchen in dieser Version einen neuen Build. Die App hat keine Verbindung zu einem Redaktionsbereich. Vor einem öffentlichen Test bitte die eingetragenen Termine und Öffnungszeiten bestätigen. Abgelaufene Veranstaltungen verschwinden automatisch aus der Liste.

Für TestFlight und die Veröffentlichung ist nach dem ersten Xcode-Build das Apple-Entwicklerteam für die Signierung auszuwählen. Danach kann ein Archiv zu App Store Connect hochgeladen werden.
